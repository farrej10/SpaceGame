#pragma once
#include "enemy.h"

class EnemyNode
{
public:

	Enemy* theEnemy;
	EnemyNode* nextEnemy;


	EnemyNode(Enemy* theEnemyB);




};

