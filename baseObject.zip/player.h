#pragma once
#include "character.h"
#include "Bullet.h"

class Player :public Character
{
public:
	int gunDamage;
	int score;


	Player();
	Player(SDL_Rect rect, SDL_Rect colrect, int imageNUMB, int healthB, int movementSpeedB, int gunDamageB);
	void move(int direction);// 0 right, 1 left, 2 up, 3 down, 4 upright, 5 downright, 6 upleft, 7 downleft
	Bullet* fire();

};